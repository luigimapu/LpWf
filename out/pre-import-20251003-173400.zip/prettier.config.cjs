module.exports = {
    printWidth: 100,
    tabWidth: 4,
    singleQuote: true,
    trailingComma: 'all',
    semi: true,
    bracketSpacing: true,
};
